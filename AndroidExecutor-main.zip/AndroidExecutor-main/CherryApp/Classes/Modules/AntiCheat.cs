﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CherryApp.Classes.Modules
{
    public class AntiCheat
    {
        /* 
        For An Anti-Cheat Bypass Following A Static Class Would Not Be Suitable Consider Making Instance
        Use Methods I Placed In Memory.cs To Achieve What You Need :Sunglass: ~ Immune

        This won't be needed anymore ~ Joe
        */
    }
}
